// src/App.js
// Nenhuma importação explícita de React é necessária para usar JSX no React 17+
import { TarefasProvider } from './context/TarefasContext';
import ListaTarefas from './components/ListaTarefas'; // Importa o componente ListaTarefas (novo nome)
import './App.css'; // Importa o arquivo CSS para estilos globais

function App() {
  return (
    // TarefasProvider envolve toda a aplicação (ou a parte que precisa de acesso ao estado global)
    // Isso torna o 'state' e 'dispatch' do contexto acessíveis em qualquer componente filho
    <TarefasProvider>
      <div className="App">
        <h1>Organizador de Tarefas</h1> {/* Título do app */}
        {/* O componente ListaTarefas conterá o input para adicionar, os botões de filtro e a lista de tarefas */}
        <ListaTarefas />
      </div>
    </TarefasProvider>
  );
}

export default App;